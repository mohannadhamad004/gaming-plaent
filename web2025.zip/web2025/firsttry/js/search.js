document.addEventListener("DOMContentLoaded", () => {
    const resultsContainer = document.getElementById("search-results");
    const results = JSON.parse(localStorage.getItem("searchResults")) || [];

    if (results.length === 0) {
        resultsContainer.innerHTML = "<p>No products found.</p>";
        return;
    }

    results.forEach(p => {
        const card = document.createElement("div");
        card.className = "product-card";
        card.innerHTML = `
            <img src="${p.image}" alt="${p.name}">
            <h3>${p.name}</h3>
            <p>${p.description}</p>
            <div class="price">$${p.price}</div>
            <button onclick="addToCart(${p.id})">Add to Cart</button>
        `;
        resultsContainer.appendChild(card);
    });
});

// Copy cart functions (simplified)
function addToCart(productId) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push(productId);
    localStorage.setItem("cart", JSON.stringify(cart));
    showNotification("✅ Added to cart!");
}

function showNotification(message) {
    const note = document.createElement("div");
    note.className = "notification-popup";
    note.textContent = message;
    document.body.appendChild(note);

    setTimeout(() => note.classList.add("visible"), 50);
    setTimeout(() => {
        note.classList.remove("visible");
        setTimeout(() => note.remove(), 300);
    }, 2000);
}
