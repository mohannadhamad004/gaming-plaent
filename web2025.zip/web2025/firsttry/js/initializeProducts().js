const products = {
    featured: [
        {
            id: 1,
            name: "NVIDIA RTX 4090",
            price: 1599,
            image: "https://cdn.mos.cms.futurecdn.net/JDE5VAFY5bZCFrkvrR6v6M.jpg",
            description: "The ultimate GPU for gaming and AI performance."
        },
        {
            id: 2,
            name: "Intel Core i9-14900K",
            price: 599,
            image: "https://cdn.mos.cms.futurecdn.net/zFv3xr3GyqBNkkC1QxYzvR.jpg",
            description: "Unmatched performance for high-end desktops."
        }
    ],
    specialOffers: [
        {
            id: 3,
            name: "AMD Ryzen 9 7950X",
            price: 499,
            image: "https://cdn.mos.cms.futurecdn.net/NDFpsTzGvT8p9W63RRLrAa.jpg",
            description: "Powerful 16-core processor at a special price!"
        },
        {
            id: 4,
            name: "ASUS TUF Gaming Monitor",
            price: 299,
            image: "https://cdn.mos.cms.futurecdn.net/QhQ85ZmnZC3rP2RfL3G6rR.jpg",
            description: "Smooth 165Hz refresh rate, great for gamers."
        }
    ],
    gpu: [],
    cpu: [],
    accessories: []
};

document.addEventListener("DOMContentLoaded", () => {
    displayProducts(products.featured, "featured-products");
    displayProducts(products.specialOffers, "special-offers");
    initializeCart();
    initializeSearch();
});

function displayProducts(productArray, containerId) {
    const container = document.getElementById(containerId);
    container.innerHTML = "";
    productArray.forEach(p => {
        const card = document.createElement("div");
        card.className = "product-card";
        card.innerHTML = `
            <img src="${p.image}" alt="${p.name}">
            <h3>${p.name}</h3>
            <p>${p.description}</p>
            <div class="price">$${p.price}</div>
            <button onclick="addToCart(${p.id})">Add to Cart</button>
        `;
        container.appendChild(card);
    });
}

// 🛒 Shopping Cart System
function addToCart(productId) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push(productId);
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCartCount();
    showNotification("✅ Added to cart!");
}

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    document.getElementById("cart-count").textContent = cart.length;
}

function initializeCart() {
    updateCartCount();
}

// 🔍 Search System
function initializeSearch() {
    const searchInput = document.querySelector(".search-box input");
    const searchButton = document.querySelector(".search-box button");

    if (!searchInput || !searchButton) return;

    searchButton.addEventListener("click", () => performSearch(searchInput.value));
    searchInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") performSearch(searchInput.value);
    });
}

function performSearch(query) {
    if (!query.trim()) return;

    const allProducts = getAllProducts();
    const results = allProducts.filter(p =>
        p.name.toLowerCase().includes(query.toLowerCase()) ||
        p.description.toLowerCase().includes(query.toLowerCase())
    );

    localStorage.setItem("searchResults", JSON.stringify(results));
    window.location.href = "search.html";
}

function getAllProducts() {
    return [
        ...products.featured,
        ...products.specialOffers,
        ...products.gpu,
        ...products.cpu,
        ...products.accessories
    ];
}

// 🔔 Notification System
function showNotification(message) {
    const note = document.createElement("div");
    note.className = "notification-popup";
    note.textContent = message;
    document.body.appendChild(note);

    setTimeout(() => note.classList.add("visible"), 50);
    setTimeout(() => {
        note.classList.remove("visible");
        setTimeout(() => note.remove(), 300);
    }, 2000);
}
document.addEventListener('DOMContentLoaded', () => {
    // Insert header HTML into placeholder
    const placeholder = document.getElementById('navbar-placeholder');
    if (placeholder) {
        placeholder.innerHTML = `
            <header class="header">
                <div class="container">
                    <div class="logo">
                        <h1><a href="index.html">TechParts</a></h1>
                    </div>

                    <nav class="nav">
                        <ul>
                            <li><a href="index.html">Home</a></li>
                            <li><a href="prebuilt.html">Pre-Built PCs</a></li>
                            <li><a href="laptops.html">Laptops</a></li>
                            <li><a href="parts.html">Parts</a></li>
                            <li><a href="accessories.html">Accessories</a></li>
                            <li><a href="custom-build.html">Custom Build</a></li>
                            <li><a href="admin.html">Admin</a></li>
                        </ul>
                    </nav>

                    <div class="header-actions">
                        <div class="auth-buttons">
                            <a href="login.html" class="btn-login">Login</a>
                            <a href="register.html" class="btn-register">Register</a>
                        </div>
                        <div class="search-box">
                            <input type="text" id="navbarSearch" placeholder="Search products..." />
                            <button type="button"><i class="fas fa-search"></i></button>
                        </div>
                        <div class="cart">
                            <i class="fas fa-shopping-cart fa-lg"></i>
                            <span class="cart-count">0</span>
                        </div>
                    </div>
                </div>
            </header>
        `;
    }

    // Helper: get filename from pathname (defaults to index.html)
    const getFilename = (pathname) => {
        const p = pathname.split('/');
        let name = p.pop() || p.pop() || '';
        return name === '' ? 'index.html' : name;
    };

    const currentFile = getFilename(location.pathname);

    // Remove any hardcoded 'active' classes in nav and footer
    document.querySelectorAll('.nav a, .footer-section a').forEach(a => a.classList.remove('active'));

    // Set 'active' on nav links that match the current filename.
    // Use a temporary anchor element to resolve relative hrefs reliably.
    document.querySelectorAll('.nav a').forEach(link => {
        const href = link.getAttribute('href');
        if (!href) return;
        try {
            const tmp = document.createElement('a');
            tmp.href = href; // browser resolves relative hrefs
            const linkFile = getFilename(tmp.pathname);
            if (linkFile === currentFile) link.classList.add('active');
        } catch (e) {
            // ignore invalid hrefs
        }
    });

    // Also set active in footer links (optional)
    document.querySelectorAll('.footer-section a').forEach(link => {
        const href = link.getAttribute('href');
        if (!href) return;
        try {
            const tmp = document.createElement('a');
            tmp.href = href;
            const linkFile = getFilename(tmp.pathname);
            if (linkFile === currentFile) link.classList.add('active');
        } catch (e) {}
    });

    // Optional: simple search button handler
    const searchBtn = document.querySelector('#navbarSearch')?.nextElementSibling;
    if (searchBtn) {
        searchBtn.addEventListener('click', () => {
            const q = document.getElementById('navbarSearch').value.trim();
            if (q) console.log('Search for:', q);
        });
    }
});