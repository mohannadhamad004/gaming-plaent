(function(){
  function frag(html){ const t=document.createElement('template'); t.innerHTML=html.trim(); return t.content; }
  function ensureCss(href){
    const found=[...document.querySelectorAll('link[rel="stylesheet"]')].some(l=> (l.getAttribute('href')||'').includes(href));
    if(!found){ const l=document.createElement('link'); l.rel='stylesheet'; l.href=href; document.head.appendChild(l); }
  }
  ensureCss('css/navbar.css'); ensureCss('css/body.css'); ensureCss('css/footer.css');
  if (![...document.querySelectorAll('link[rel="stylesheet"]')].some(l=> (l.href||'').includes('font-awesome'))){
    const fa=document.createElement('link'); fa.rel='stylesheet'; fa.href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css'; document.head.appendChild(fa);
  }

  /* ✅ NEW NAVBAR HTML */
  const navHTML = `
<header class="header">
  <div class="container">
    <div class="logo"><h1><a href="index.html">TechParts</a></h1></div>

    <nav class="nav">
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="pre-build.html">Pre-Built PCs</a></li>
        <li><a href="laptops.html">Laptops</a></li>
        <li><a href="parts.html">Parts</a></li>
        <li><a href="accessories.html" class="active">Accessories</a></li>
        <li><a href="custom-build.html">Custom Build</a></li>
        <li><a href="admin.html">Admin</a></li>
      </ul>
    </nav>

    <div class="header-actions">

      <div class="search-box">
        <input id="navbarSearch" type="text" placeholder="Search products...">
        <button><i class="fas fa-search"></i></button>

        <!-- ✅ Search Suggestions -->
        <ul class="search-suggestions hidden"></ul>
      </div>

      <a href="login.html" class="btn-login">Login</a>
      <a href="register.html" class="btn-register">Register</a>

      <!-- ✅ Cart + Dropdown -->
      <div class="cart" id="global-cart">
        <i class="fas fa-shopping-cart"></i>
        <span class="cart-count">0</span>

        <div class="cart-dropdown hidden">
          <div class="cart-items"></div>
          <a href="cart.html" class="checkout-btn">View Cart</a>
        </div>
      </div>

    </div>
  </div>
</header>
`;

  /* Insert Navbar */
  let ph=document.getElementById('navbar-placeholder');
  if(!ph){ ph=document.createElement('div'); ph.id='navbar-placeholder';
    if(document.body.firstElementChild) document.body.insertBefore(ph, document.body.firstElementChild);
    else document.body.appendChild(ph);
  }
  ph.appendChild(frag(navHTML));

  /* CART LOGIC */
  function getCart(){ try{ return JSON.parse(localStorage.getItem('cart'))||[] }catch(e){ return [] } }
  function setCart(v){ localStorage.setItem('cart', JSON.stringify(v)); }
  function updateCartCount(){ const el=document.querySelector('.cart-count'); if(el) el.textContent=String(getCart().length); }
  window.addToCart = function(productName){
    const c=getCart(); c.push(productName); setCart(c); updateCartCount();
    document.querySelector('.cart-items').innerHTML = c.map(i=>`<div>${i}</div>`).join('');
  };

  updateCartCount();

  /* ✅ Cart Dropdown toggle */
  const cart = document.getElementById("global-cart");
  const dropdown = cart.querySelector(".cart-dropdown");
  cart.addEventListener("click", ()=> dropdown.classList.toggle("hidden"));

  /* ✅ Search Suggestions */
  const searchInput = document.getElementById("navbarSearch");
  const suggestBox = document.querySelector(".search-suggestions");

  searchInput.addEventListener("input", ()=>{
    const q = searchInput.value.toLowerCase();
    if(!window.accessories) return;
    const results = accessories.filter(a => a.name.toLowerCase().includes(q)).slice(0,6);
    suggestBox.innerHTML = results.map(r=>`<li>${r.name}</li>`).join('');
    suggestBox.classList.toggle("hidden", results.length === 0);
    suggestBox.querySelectorAll("li").forEach(li=>{
      li.addEventListener("click", ()=>{
        searchInput.value = li.textContent;
        suggestBox.classList.add("hidden");
      });
    });
  });
})();
